PyQt on Raspberry
===========

![](img/screenshot.png) 