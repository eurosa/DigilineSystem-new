qt-stop-watch.py
================

A stop watch... as simple as it gets.
